-- ============================================================
-- BARRIO VIVO — Script SQL para Supabase (PostgreSQL + PostGIS)
-- Version: 1.0 | ACID compliant | Free Tier optimizado
-- Ejecutar en: Supabase Dashboard > SQL Editor
-- Orden de ejecucion: de arriba a abajo, sin saltarse secciones
-- ============================================================


-- ============================================================
-- PASO 0: EXTENSIONES NECESARIAS
-- Supabase tiene PostGIS disponible, solo hay que activarlo
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";      -- UUIDs seguros
CREATE EXTENSION IF NOT EXISTS "postgis";         -- Geolocalización real
CREATE EXTENSION IF NOT EXISTS "pg_trgm";         -- Búsqueda de texto fuzzy (buscar "tortilla" y encontrar "tortillería")
CREATE EXTENSION IF NOT EXISTS "unaccent";        -- Búsqueda sin acentos (buscar "pollos" encuentra "Pollería")


-- ============================================================
-- PASO 1: ENUMS
-- Tipos fijos que no cambian. Más eficientes que VARCHAR.
-- ============================================================

CREATE TYPE rol_usuario AS ENUM ('usuario', 'vendedor', 'admin');

CREATE TYPE estado_negocio AS ENUM (
  'activo',      -- Visible en el directorio
  'pendiente',   -- Recién registrado, esperando primera verificación
  'suspendido',  -- Suspendido por admin (violación de reglas)
  'inactivo'     -- El propio dueño lo desactivó
);

CREATE TYPE tipo_badge AS ENUM (
  'verificado_comunidad',  -- Vecinos confirmaron que existe
  'top_rated',             -- Rating >= 4.5 con mínimo 10 reseñas
  'eco_friendly',          -- El vendedor declaró prácticas sustentables
  'historia_local',        -- Negocio ancestral (>= 15 años en el barrio)
  'muy_visitado'           -- Top 10% de visitas en su colonia
);

CREATE TYPE modo_visita AS ENUM (
  'manual',     -- Usuario tocó "Visité este negocio"
  'gps'         -- GPS detectó que estuvo cerca (futuro)
);


-- ============================================================
-- PASO 2: TABLA PERFILES
-- Extiende auth.users de Supabase. NO duplica email ni password.
-- Se crea automáticamente cuando alguien se registra (trigger al final).
-- ============================================================

CREATE TABLE public.perfiles (
  -- PK que referencia directamente el usuario de Supabase Auth
  id                UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Datos personales
  nombre            VARCHAR(100) NOT NULL CHECK (LENGTH(TRIM(nombre)) >= 2),
  telefono          VARCHAR(20),

  -- Rol dentro de la plataforma
  rol               rol_usuario NOT NULL DEFAULT 'usuario',

  -- Ubicación del usuario (para calcular distancias)
  -- GEOGRAPHY(POINT, 4326) = latitud/longitud en sistema WGS84 (el de GPS)
  ubicacion         GEOGRAPHY(POINT, 4326),
  colonia           VARCHAR(100),
  ciudad            VARCHAR(100) DEFAULT 'Ciudad de México',

  -- Foto de perfil (URL de Supabase Storage)
  avatar_url        TEXT,

  -- Control
  activo            BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Soft delete: si tiene fecha, está borrado lógicamente
  deleted_at        TIMESTAMPTZ
);

COMMENT ON TABLE public.perfiles IS 'Perfil público de cada usuario. Extiende auth.users.';
COMMENT ON COLUMN public.perfiles.ubicacion IS 'GEOGRAPHY(POINT): longitud primero, luego latitud. Ej: ST_SetSRID(ST_MakePoint(-99.1332, 19.4326), 4326)';


-- ============================================================
-- PASO 3: TABLA CATEGORIAS
-- Catálogo de tipos de negocio. 3 grandes grupos + subcategorías.
-- ============================================================

CREATE TABLE public.categorias (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre          VARCHAR(100) NOT NULL UNIQUE,
  descripcion     TEXT,
  icono           VARCHAR(10) NOT NULL,              -- Emoji representativo
  color_hex       VARCHAR(7) NOT NULL DEFAULT '#C0392B', -- Color en UI
  grupo           VARCHAR(50) NOT NULL,              -- 'alimentos', 'servicios', 'circular'
  orden           SMALLINT NOT NULL DEFAULT 0,       -- Para ordenar en la UI
  activo          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE public.categorias IS 'Catálogo de categorías de negocios. Administrado por admin.';


-- ============================================================
-- PASO 4: TABLA NEGOCIOS (entidad principal)
-- ============================================================

CREATE TABLE public.negocios (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Propietario del negocio (FK a perfiles, NO a auth.users directamente)
  propietario_id        UUID NOT NULL REFERENCES public.perfiles(id)
                        ON DELETE RESTRICT,  -- No borrar perfil si tiene negocios activos
  categoria_id          UUID NOT NULL REFERENCES public.categorias(id)
                        ON DELETE RESTRICT,

  -- Información básica
  nombre                VARCHAR(150) NOT NULL CHECK (LENGTH(TRIM(nombre)) >= 2),
  descripcion           TEXT,                        -- Descripción breve para el directorio
  historia              TEXT,                        -- Storytelling: quién es, cuántos años, tradición
  cita_vendedor         TEXT,                        -- "Llevo 40 años haciendo tortillas a mano"
  nombre_vendedor       VARCHAR(100),                -- "Doña Carmen" para mostrar en historia

  -- Datos de contacto
  telefono              VARCHAR(20),
  whatsapp              VARCHAR(20),
  sitio_web             TEXT,

  -- Ubicación física
  -- GEOGRAPHY(POINT, 4326): permite queries ST_DWithin para radio exacto
  ubicacion             GEOGRAPHY(POINT, 4326) NOT NULL,
  direccion             TEXT NOT NULL,
  colonia               VARCHAR(100) NOT NULL,
  ciudad                VARCHAR(100) NOT NULL DEFAULT 'Ciudad de México',
  referencia            TEXT,                        -- "Junto a la farmacia Benavides"

  -- Información operativa
  horario               JSONB,                       -- JSON flexible para horarios por día
  -- Formato horario: {"lunes": {"abre": "07:00", "cierra": "14:00", "cerrado": false}, ...}
  anios_en_barrio       SMALLINT CHECK (anios_en_barrio >= 0 AND anios_en_barrio <= 200),

  -- Fotos (MVP: foto principal como URL. Supabase Storage path)
  foto_url              TEXT,
  foto_hero_url         TEXT,                        -- Foto grande para el header de detalle

  -- Sustentabilidad declarada por el vendedor
  es_eco_friendly       BOOLEAN NOT NULL DEFAULT FALSE,
  practicas_eco         TEXT,                        -- Descripción de sus prácticas verdes

  -- Estado y moderación
  estado                estado_negocio NOT NULL DEFAULT 'pendiente',

  -- Contadores desnormalizados (actualizados por triggers — ACID garantiza consistencia)
  -- NO calcular con JOINs en cada query: sería muy lento con miles de registros
  rating_promedio       DECIMAL(3,2) DEFAULT 0.00 CHECK (rating_promedio >= 0 AND rating_promedio <= 5),
  total_resenas         INTEGER NOT NULL DEFAULT 0 CHECK (total_resenas >= 0),
  total_visitas         INTEGER NOT NULL DEFAULT 0 CHECK (total_visitas >= 0),
  total_verificaciones  INTEGER NOT NULL DEFAULT 0 CHECK (total_verificaciones >= 0),

  -- Control
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at            TIMESTAMPTZ,                 -- Soft delete

  -- Constraints de negocio
  CONSTRAINT nombre_no_vacio CHECK (TRIM(nombre) <> ''),
  CONSTRAINT horario_es_objeto CHECK (horario IS NULL OR jsonb_typeof(horario) = 'object')
);

COMMENT ON TABLE public.negocios IS 'Negocios del directorio Barrio Vivo. Entidad principal.';
COMMENT ON COLUMN public.negocios.horario IS 'JSON: {"lunes":{"abre":"07:00","cierra":"14:00","cerrado":false},...}';
COMMENT ON COLUMN public.negocios.rating_promedio IS 'Actualizado automáticamente por trigger al insertar/borrar reseñas.';
COMMENT ON COLUMN public.negocios.total_visitas IS 'Actualizado automáticamente por trigger al insertar visitas.';


-- ============================================================
-- PASO 5: TABLA RESEÑAS (transaccional)
-- ============================================================

CREATE TABLE public.resenas (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  negocio_id      UUID NOT NULL REFERENCES public.negocios(id) ON DELETE CASCADE,
  autor_id        UUID NOT NULL REFERENCES public.perfiles(id) ON DELETE CASCADE,

  -- La reseña en sí
  rating          SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comentario      TEXT CHECK (LENGTH(comentario) <= 1000),

  -- Control
  activo          BOOLEAN NOT NULL DEFAULT TRUE,     -- Soft delete para reseñas
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- CRÍTICO: un usuario solo puede reseñar cada negocio UNA vez
  -- La BD garantiza esto, no solo la app
  CONSTRAINT una_resena_por_usuario_negocio UNIQUE (negocio_id, autor_id)
);

COMMENT ON TABLE public.resenas IS 'Calificaciones y comentarios de usuarios sobre negocios.';
COMMENT ON CONSTRAINT una_resena_por_usuario_negocio ON public.resenas
  IS 'ACID: garantiza que un usuario no puede dejar dos reseñas del mismo negocio.';


-- ============================================================
-- PASO 6: TABLA VISITAS (transaccional)
-- Cada vez que un usuario confirma que visitó un negocio
-- ============================================================

CREATE TABLE public.visitas (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  negocio_id        UUID NOT NULL REFERENCES public.negocios(id) ON DELETE CASCADE,
  visitante_id      UUID NOT NULL REFERENCES public.perfiles(id) ON DELETE CASCADE,

  -- Cálculo de impacto ambiental
  -- km_distancia: distancia entre ubicación del usuario y el negocio al momento de visitar
  km_distancia      DECIMAL(8,3) CHECK (km_distancia >= 0),
  -- co2_ahorrado = km_distancia * 0.21 (factor promedio CDMX en kg CO₂/km)
  co2_ahorrado_kg   DECIMAL(8,4) CHECK (co2_ahorrado_kg >= 0),
  -- Dinero que el usuario reporta haber gastado (para métrica de economía local)
  gasto_reportado   DECIMAL(10,2) CHECK (gasto_reportado >= 0),

  -- Modo de registro (manual o GPS — futuro)
  modo              modo_visita NOT NULL DEFAULT 'manual',
  -- GPS del usuario al momento de la visita (para validación futura)
  ubicacion_visita  GEOGRAPHY(POINT, 4326),

  -- Control
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
  -- Las visitas NO tienen soft delete: son registros históricos permanentes
  -- Si hay un error, se puede anular con un registro negativo o flag
);

COMMENT ON TABLE public.visitas IS 'Registro de visitas confirmadas a negocios. Fuente de las métricas de impacto.';
COMMENT ON COLUMN public.visitas.co2_ahorrado_kg IS 'Calculado como km_distancia * 0.21. Factor: emisión promedio auto en CDMX.';


-- ============================================================
-- PASO 7: TABLA VERIFICACIONES
-- Vecinos que confirman que un negocio existe y es real
-- ============================================================

CREATE TABLE public.verificaciones (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  negocio_id      UUID NOT NULL REFERENCES public.negocios(id) ON DELETE CASCADE,
  verificador_id  UUID NOT NULL REFERENCES public.perfiles(id) ON DELETE CASCADE,
  -- true = confirmé que existe, false = reporté que no existe o es falso
  confirma        BOOLEAN NOT NULL DEFAULT TRUE,
  nota            TEXT CHECK (LENGTH(nota) <= 300),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Un vecino solo puede verificar cada negocio una vez
  CONSTRAINT una_verificacion_por_usuario UNIQUE (negocio_id, verificador_id)
);

COMMENT ON TABLE public.verificaciones IS 'Vecinos que confirman la existencia de un negocio. Base del sistema de confianza comunitaria.';


-- ============================================================
-- PASO 8: TABLA BADGES (catálogo + asignación)
-- ============================================================

CREATE TABLE public.badges (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tipo            tipo_badge NOT NULL UNIQUE,
  nombre          VARCHAR(80) NOT NULL,
  descripcion     TEXT,
  icono           VARCHAR(10) NOT NULL,
  color_hex       VARCHAR(7) NOT NULL DEFAULT '#1A7A4A',
  criterio        TEXT NOT NULL   -- Descripción legible del criterio para obtenerlo
);

-- Relación negocio ↔ badges (un negocio puede tener múltiples badges)
CREATE TABLE public.negocio_badges (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  negocio_id      UUID NOT NULL REFERENCES public.negocios(id) ON DELETE CASCADE,
  badge_tipo      tipo_badge NOT NULL,
  otorgado_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  -- Un negocio solo puede tener cada badge una vez
  CONSTRAINT un_badge_por_negocio UNIQUE (negocio_id, badge_tipo)
);

COMMENT ON TABLE public.negocio_badges IS 'Badges asignados a negocios. Actualizados por función assign_badges().';


-- ============================================================
-- PASO 9: ÍNDICES
-- Críticos para performance en queries frecuentes
-- ============================================================

-- Búsqueda geográfica: el más importante de toda la app
-- GIST index es el apropiado para tipos GEOGRAPHY
CREATE INDEX idx_negocios_ubicacion ON public.negocios USING GIST (ubicacion)
  WHERE deleted_at IS NULL;

-- Búsqueda de texto: negocios por nombre/descripción
-- GIN con trigrams permite búsqueda parcial y fuzzy
CREATE INDEX idx_negocios_nombre_trgm ON public.negocios
  USING GIN (to_tsvector('spanish', unaccent(nombre || ' ' || COALESCE(descripcion, ''))));

-- Filtros frecuentes en el directorio
CREATE INDEX idx_negocios_categoria ON public.negocios (categoria_id)
  WHERE deleted_at IS NULL AND estado = 'activo';
CREATE INDEX idx_negocios_estado ON public.negocios (estado)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_negocios_propietario ON public.negocios (propietario_id)
  WHERE deleted_at IS NULL;
CREATE INDEX idx_negocios_rating ON public.negocios (rating_promedio DESC)
  WHERE deleted_at IS NULL AND estado = 'activo';
CREATE INDEX idx_negocios_colonia ON public.negocios (colonia)
  WHERE deleted_at IS NULL;

-- Reseñas: queries por negocio son las más comunes
CREATE INDEX idx_resenas_negocio ON public.resenas (negocio_id)
  WHERE activo = TRUE;
CREATE INDEX idx_resenas_autor ON public.resenas (autor_id);

-- Visitas: para calcular impacto del usuario
CREATE INDEX idx_visitas_visitante ON public.visitas (visitante_id);
CREATE INDEX idx_visitas_negocio ON public.visitas (negocio_id);
-- Para queries de impacto por período
CREATE INDEX idx_visitas_fecha ON public.visitas (created_at DESC);
-- Para queries combinadas de impacto por usuario + período
CREATE INDEX idx_visitas_visitante_fecha ON public.visitas (visitante_id, created_at DESC);

-- Verificaciones
CREATE INDEX idx_verificaciones_negocio ON public.verificaciones (negocio_id);

-- Perfiles: para búsquedas geográficas de usuarios cercanos (futuro)
CREATE INDEX idx_perfiles_ubicacion ON public.perfiles USING GIST (ubicacion)
  WHERE deleted_at IS NULL;


-- ============================================================
-- PASO 10: FUNCIONES UTILITARIAS
-- ============================================================

-- Función para calcular CO₂ ahorrado en kg
-- Factor: 0.21 kg CO₂/km (emisión promedio auto en CDMX)
CREATE OR REPLACE FUNCTION public.calcular_co2(km_distancia DECIMAL)
RETURNS DECIMAL AS $$
BEGIN
  RETURN ROUND((km_distancia * 0.21)::DECIMAL, 4);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

COMMENT ON FUNCTION public.calcular_co2 IS
  'Calcula kg de CO₂ ahorrado dado un número de km. Factor: 0.21 kg/km (promedio CDMX).';


-- Función para calcular distancia en km entre dos puntos geográficos
CREATE OR REPLACE FUNCTION public.distancia_km(
  punto1 GEOGRAPHY,
  punto2 GEOGRAPHY
)
RETURNS DECIMAL AS $$
BEGIN
  -- ST_Distance retorna metros, dividimos entre 1000
  RETURN ROUND((ST_Distance(punto1, punto2) / 1000.0)::DECIMAL, 3);
END;
$$ LANGUAGE plpgsql IMMUTABLE;


-- Función que actualiza updated_at automáticamente
-- Se usará como trigger en todas las tablas que lo necesiten
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- ============================================================
-- PASO 11: TRIGGERS ACID — Los más importantes del sistema
-- Garantizan consistencia de contadores sin importar cómo se inserte
-- ============================================================

-- TRIGGER 1: Recalcular rating_promedio y total_resenas al insertar/editar/borrar reseña
-- ATOMICIDAD: el insert de la reseña y la actualización del contador son una sola transacción
CREATE OR REPLACE FUNCTION public.recalcular_rating_negocio()
RETURNS TRIGGER AS $$
DECLARE
  nuevo_rating    DECIMAL(3,2);
  nuevo_total     INTEGER;
BEGIN
  -- Calcular el nuevo promedio y total con las reseñas activas
  SELECT
    COALESCE(ROUND(AVG(rating)::DECIMAL, 2), 0.00),
    COUNT(*)
  INTO nuevo_rating, nuevo_total
  FROM public.resenas
  WHERE negocio_id = COALESCE(NEW.negocio_id, OLD.negocio_id)
    AND activo = TRUE;

  -- Actualizar el negocio en la misma transacción
  UPDATE public.negocios
  SET
    rating_promedio = nuevo_rating,
    total_resenas   = nuevo_total,
    updated_at      = NOW()
  WHERE id = COALESCE(NEW.negocio_id, OLD.negocio_id);

  -- Después de actualizar el rating, revisar si merece el badge top_rated
  PERFORM public.evaluar_badge_top_rated(COALESCE(NEW.negocio_id, OLD.negocio_id));

  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_rating_negocio
  AFTER INSERT OR UPDATE OR DELETE ON public.resenas
  FOR EACH ROW EXECUTE FUNCTION public.recalcular_rating_negocio();


-- TRIGGER 2: Incrementar total_visitas al registrar una visita
CREATE OR REPLACE FUNCTION public.incrementar_visitas_negocio()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.negocios
  SET
    total_visitas = total_visitas + 1,
    updated_at    = NOW()
  WHERE id = NEW.negocio_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_visitas_negocio
  AFTER INSERT ON public.visitas
  FOR EACH ROW EXECUTE FUNCTION public.incrementar_visitas_negocio();


-- TRIGGER 3: Actualizar total_verificaciones
CREATE OR REPLACE FUNCTION public.actualizar_verificaciones_negocio()
RETURNS TRIGGER AS $$
DECLARE
  nuevo_total INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO nuevo_total
  FROM public.verificaciones
  WHERE negocio_id = COALESCE(NEW.negocio_id, OLD.negocio_id)
    AND confirma = TRUE;

  UPDATE public.negocios
  SET
    total_verificaciones = nuevo_total,
    updated_at           = NOW()
  WHERE id = COALESCE(NEW.negocio_id, OLD.negocio_id);

  -- Si tiene 3+ verificaciones positivas, cambiar estado a 'activo'
  UPDATE public.negocios
  SET estado = 'activo'
  WHERE id = COALESCE(NEW.negocio_id, OLD.negocio_id)
    AND estado = 'pendiente'
    AND total_verificaciones >= 3;

  -- Evaluar badge de verificación comunitaria
  PERFORM public.evaluar_badge_verificado(COALESCE(NEW.negocio_id, OLD.negocio_id));

  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_verificaciones_negocio
  AFTER INSERT OR DELETE ON public.verificaciones
  FOR EACH ROW EXECUTE FUNCTION public.actualizar_verificaciones_negocio();


-- TRIGGER 4: Crear perfil automáticamente cuando alguien se registra en Supabase Auth
-- Este trigger es CRÍTICO: conecta auth.users con public.perfiles
CREATE OR REPLACE FUNCTION public.crear_perfil_nuevo_usuario()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.perfiles (id, nombre, rol, created_at, updated_at)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nombre', split_part(NEW.email, '@', 1)),
    'usuario',
    NOW(),
    NOW()
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Este trigger se ejecuta en el schema auth (requiere permisos especiales en Supabase)
CREATE TRIGGER trigger_crear_perfil
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.crear_perfil_nuevo_usuario();


-- TRIGGER 5: Actualizar updated_at automáticamente
CREATE TRIGGER trigger_updated_at_perfiles
  BEFORE UPDATE ON public.perfiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trigger_updated_at_negocios
  BEFORE UPDATE ON public.negocios
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER trigger_updated_at_resenas
  BEFORE UPDATE ON public.resenas
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


-- ============================================================
-- PASO 12: FUNCIONES DE BADGES
-- Evalúan y asignan/quitan badges automáticamente
-- ============================================================

-- Badge: Verificado por comunidad (>= 5 verificaciones positivas)
CREATE OR REPLACE FUNCTION public.evaluar_badge_verificado(negocio_uuid UUID)
RETURNS VOID AS $$
BEGIN
  IF (SELECT total_verificaciones FROM public.negocios WHERE id = negocio_uuid) >= 5 THEN
    INSERT INTO public.negocio_badges (negocio_id, badge_tipo)
    VALUES (negocio_uuid, 'verificado_comunidad')
    ON CONFLICT (negocio_id, badge_tipo) DO NOTHING;
  ELSE
    DELETE FROM public.negocio_badges
    WHERE negocio_id = negocio_uuid AND badge_tipo = 'verificado_comunidad';
  END IF;
END;
$$ LANGUAGE plpgsql;


-- Badge: Top-rated (rating >= 4.5 con >= 10 reseñas)
CREATE OR REPLACE FUNCTION public.evaluar_badge_top_rated(negocio_uuid UUID)
RETURNS VOID AS $$
DECLARE
  neg RECORD;
BEGIN
  SELECT rating_promedio, total_resenas INTO neg
  FROM public.negocios WHERE id = negocio_uuid;

  IF neg.rating_promedio >= 4.5 AND neg.total_resenas >= 10 THEN
    INSERT INTO public.negocio_badges (negocio_id, badge_tipo)
    VALUES (negocio_uuid, 'top_rated')
    ON CONFLICT (negocio_id, badge_tipo) DO NOTHING;
  ELSE
    DELETE FROM public.negocio_badges
    WHERE negocio_id = negocio_uuid AND badge_tipo = 'top_rated';
  END IF;
END;
$$ LANGUAGE plpgsql;


-- Badge: Historia local (>= 15 años en el barrio)
-- Se puede llamar al actualizar anios_en_barrio
CREATE OR REPLACE FUNCTION public.evaluar_badge_historia_local(negocio_uuid UUID)
RETURNS VOID AS $$
BEGIN
  IF (SELECT anios_en_barrio FROM public.negocios WHERE id = negocio_uuid) >= 15 THEN
    INSERT INTO public.negocio_badges (negocio_id, badge_tipo)
    VALUES (negocio_uuid, 'historia_local')
    ON CONFLICT (negocio_id, badge_tipo) DO NOTHING;
  ELSE
    DELETE FROM public.negocio_badges
    WHERE negocio_id = negocio_uuid AND badge_tipo = 'historia_local';
  END IF;
END;
$$ LANGUAGE plpgsql;


-- ============================================================
-- PASO 13: VISTAS (para queries frecuentes sin repetir lógica)
-- ============================================================

-- Vista: Negocios activos con todos sus datos + badges agregados
-- El frontend puede hacer queries directas a esta vista
CREATE OR REPLACE VIEW public.v_negocios_directorio AS
SELECT
  n.id,
  n.nombre,
  n.descripcion,
  n.historia,
  n.cita_vendedor,
  n.nombre_vendedor,
  n.telefono,
  n.whatsapp,
  n.direccion,
  n.colonia,
  n.ciudad,
  n.referencia,
  n.horario,
  n.anios_en_barrio,
  n.foto_url,
  n.foto_hero_url,
  n.es_eco_friendly,
  n.practicas_eco,
  n.estado,
  n.rating_promedio,
  n.total_resenas,
  n.total_visitas,
  n.total_verificaciones,
  n.created_at,
  -- Coordenadas extraídas del tipo GEOGRAPHY para el frontend
  ST_Y(n.ubicacion::geometry) AS lat,
  ST_X(n.ubicacion::geometry) AS lng,
  -- Categoría
  c.nombre      AS categoria_nombre,
  c.icono       AS categoria_icono,
  c.color_hex   AS categoria_color,
  c.grupo       AS categoria_grupo,
  -- Propietario (solo datos públicos)
  p.nombre      AS propietario_nombre,
  p.avatar_url  AS propietario_avatar,
  -- Badges como array JSON
  COALESCE(
    (SELECT jsonb_agg(nb.badge_tipo ORDER BY nb.otorgado_at)
     FROM public.negocio_badges nb
     WHERE nb.negocio_id = n.id),
    '[]'::jsonb
  ) AS badges
FROM public.negocios n
INNER JOIN public.categorias c ON n.categoria_id = c.id
INNER JOIN public.perfiles p ON n.propietario_id = p.id
WHERE n.deleted_at IS NULL
  AND n.estado IN ('activo', 'pendiente');

COMMENT ON VIEW public.v_negocios_directorio IS
  'Vista principal del directorio. Incluye categoría, propietario y badges.';


-- Vista: Impacto ambiental y económico por usuario
CREATE OR REPLACE VIEW public.v_impacto_usuario AS
SELECT
  v.visitante_id,
  p.nombre            AS nombre_usuario,
  p.colonia,
  COUNT(*)            AS total_visitas,
  COUNT(DISTINCT v.negocio_id) AS negocios_distintos,
  COALESCE(ROUND(SUM(v.km_distancia)::DECIMAL, 2), 0)  AS km_totales,
  COALESCE(ROUND(SUM(v.co2_ahorrado_kg)::DECIMAL, 3), 0) AS co2_total_kg,
  COALESCE(ROUND(SUM(v.gasto_reportado)::DECIMAL, 2), 0) AS dinero_local_total,
  -- Impacto de la última semana
  COALESCE(ROUND(SUM(CASE WHEN v.created_at >= NOW() - INTERVAL '7 days'
    THEN v.km_distancia ELSE 0 END)::DECIMAL, 2), 0) AS km_semana,
  COALESCE(ROUND(SUM(CASE WHEN v.created_at >= NOW() - INTERVAL '7 days'
    THEN v.co2_ahorrado_kg ELSE 0 END)::DECIMAL, 3), 0) AS co2_semana_kg
FROM public.visitas v
INNER JOIN public.perfiles p ON v.visitante_id = p.id
GROUP BY v.visitante_id, p.nombre, p.colonia;

COMMENT ON VIEW public.v_impacto_usuario IS
  'Métricas de impacto ambiental y económico por usuario.';


-- Vista: Negocios pendientes de verificación (para admin)
CREATE OR REPLACE VIEW public.v_admin_pendientes AS
SELECT
  n.id,
  n.nombre,
  n.colonia,
  n.total_verificaciones,
  n.created_at,
  p.nombre AS propietario_nombre,
  -- email del propietario (via auth.users)
  au.email AS propietario_email,
  c.nombre AS categoria
FROM public.negocios n
INNER JOIN public.perfiles p ON n.propietario_id = p.id
INNER JOIN auth.users au ON p.id = au.id
INNER JOIN public.categorias c ON n.categoria_id = c.id
WHERE n.estado = 'pendiente'
  AND n.deleted_at IS NULL
ORDER BY n.created_at ASC;


-- ============================================================
-- PASO 14: FUNCIÓN PRINCIPAL — Buscar negocios cercanos
-- Esta es la query más importante de toda la app
-- Parámetros: lat, lng del usuario, radio en km, filtros opcionales
-- ============================================================

CREATE OR REPLACE FUNCTION public.buscar_negocios_cercanos(
  usuario_lat      DOUBLE PRECISION,
  usuario_lng      DOUBLE PRECISION,
  radio_km         DOUBLE PRECISION DEFAULT 5.0,
  categoria_filtro UUID DEFAULT NULL,
  rating_minimo    DECIMAL DEFAULT 0,
  solo_verificados BOOLEAN DEFAULT FALSE,
  limite           INTEGER DEFAULT 50,
  offset_val       INTEGER DEFAULT 0
)
RETURNS TABLE (
  id                  UUID,
  nombre              TEXT,
  descripcion         TEXT,
  cita_vendedor       TEXT,
  nombre_vendedor     TEXT,
  telefono            TEXT,
  whatsapp            TEXT,
  direccion           TEXT,
  colonia             TEXT,
  horario             JSONB,
  anios_en_barrio     SMALLINT,
  foto_url            TEXT,
  es_eco_friendly     BOOLEAN,
  estado              estado_negocio,
  rating_promedio     DECIMAL,
  total_resenas       INTEGER,
  total_visitas       INTEGER,
  total_verificaciones INTEGER,
  lat                 DOUBLE PRECISION,
  lng                 DOUBLE PRECISION,
  distancia_km        DECIMAL,
  categoria_nombre    TEXT,
  categoria_icono     TEXT,
  categoria_color     TEXT,
  propietario_nombre  TEXT,
  badges              JSONB
) AS $$
DECLARE
  punto_usuario GEOGRAPHY;
BEGIN
  -- Crear el punto geográfico del usuario
  -- ST_SetSRID(ST_MakePoint(lng, lat), 4326): LONGITUD primero, LATITUD segundo
  punto_usuario := ST_SetSRID(ST_MakePoint(usuario_lng, usuario_lat), 4326)::GEOGRAPHY;

  RETURN QUERY
  SELECT
    n.id,
    n.nombre::TEXT,
    n.descripcion::TEXT,
    n.cita_vendedor::TEXT,
    n.nombre_vendedor::TEXT,
    n.telefono::TEXT,
    n.whatsapp::TEXT,
    n.direccion::TEXT,
    n.colonia::TEXT,
    n.horario,
    n.anios_en_barrio,
    n.foto_url::TEXT,
    n.es_eco_friendly,
    n.estado,
    n.rating_promedio,
    n.total_resenas,
    n.total_visitas,
    n.total_verificaciones,
    ST_Y(n.ubicacion::geometry)                       AS lat,
    ST_X(n.ubicacion::geometry)                       AS lng,
    ROUND((ST_Distance(n.ubicacion, punto_usuario) / 1000.0)::DECIMAL, 3) AS distancia_km,
    c.nombre::TEXT                                    AS categoria_nombre,
    c.icono::TEXT                                     AS categoria_icono,
    c.color_hex::TEXT                                 AS categoria_color,
    p.nombre::TEXT                                    AS propietario_nombre,
    COALESCE(
      (SELECT jsonb_agg(nb.badge_tipo)
       FROM public.negocio_badges nb
       WHERE nb.negocio_id = n.id),
      '[]'::jsonb
    )                                                 AS badges
  FROM public.negocios n
  INNER JOIN public.categorias c ON n.categoria_id = c.id
  INNER JOIN public.perfiles p ON n.propietario_id = p.id
  WHERE
    n.deleted_at IS NULL
    AND n.estado = 'activo'
    -- FILTRO GEOGRÁFICO: ST_DWithin usa el índice GIST → muy rápido
    AND ST_DWithin(n.ubicacion, punto_usuario, radio_km * 1000)
    -- Filtros opcionales
    AND (categoria_filtro IS NULL OR n.categoria_id = categoria_filtro)
    AND n.rating_promedio >= rating_minimo
    AND (NOT solo_verificados OR n.total_verificaciones >= 5)
  ORDER BY
    -- Ordenar por distancia (más cercanos primero)
    ST_Distance(n.ubicacion, punto_usuario) ASC
  LIMIT limite
  OFFSET offset_val;
END;
$$ LANGUAGE plpgsql STABLE;

COMMENT ON FUNCTION public.buscar_negocios_cercanos IS
  'Query principal de búsqueda. Usa índice GIST para radio geográfico. Filtra por categoría, rating y verificación.';

-- Ejemplo de uso:
-- SELECT * FROM buscar_negocios_cercanos(19.3432, -99.1619, 5.0, NULL, 0, false, 20, 0);
-- (lat Coyoacán, lng Coyoacán, 5km radio, sin filtros, 20 resultados, página 0)


-- ============================================================
-- PASO 15: ROW LEVEL SECURITY (RLS)
-- El firewall de la base de datos. Nadie puede acceder a datos
-- que no le corresponden, aunque tenga la URL de la API.
-- ============================================================

-- Activar RLS en todas las tablas
ALTER TABLE public.perfiles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.negocios          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.resenas           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visitas           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.verificaciones    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.negocio_badges    ENABLE ROW LEVEL SECURITY;

-- ──────────────────────────────────────
-- POLÍTICAS: PERFILES
-- ──────────────────────────────────────

-- Cualquiera puede ver perfiles públicos (nombre, colonia, avatar)
CREATE POLICY "perfiles_lectura_publica" ON public.perfiles
  FOR SELECT USING (deleted_at IS NULL AND activo = TRUE);

-- Solo el propio usuario puede editar su perfil
CREATE POLICY "perfiles_edicion_propia" ON public.perfiles
  FOR UPDATE USING (auth.uid() = id);

-- El perfil se crea via trigger (SECURITY DEFINER), no por el usuario directamente
-- No necesita policy de INSERT para usuarios normales

-- ──────────────────────────────────────
-- POLÍTICAS: NEGOCIOS
-- ──────────────────────────────────────

-- Lectura pública: cualquiera (autenticado o no) puede ver negocios activos
CREATE POLICY "negocios_lectura_publica" ON public.negocios
  FOR SELECT USING (
    deleted_at IS NULL
    AND estado IN ('activo', 'pendiente')
  );

-- Solo el propietario puede registrar negocios (autenticado)
CREATE POLICY "negocios_insertar_autenticado" ON public.negocios
  FOR INSERT WITH CHECK (
    auth.uid() IS NOT NULL
    AND auth.uid() = propietario_id
  );

-- Solo el propietario puede editar SUS negocios
CREATE POLICY "negocios_editar_propio" ON public.negocios
  FOR UPDATE USING (
    auth.uid() = propietario_id
    AND deleted_at IS NULL
  );

-- Solo el propietario o admin puede borrar (soft delete)
CREATE POLICY "negocios_borrar_propio_o_admin" ON public.negocios
  FOR DELETE USING (
    auth.uid() = propietario_id
    OR EXISTS (
      SELECT 1 FROM public.perfiles
      WHERE id = auth.uid() AND rol = 'admin'
    )
  );

-- ──────────────────────────────────────
-- POLÍTICAS: RESEÑAS
-- ──────────────────────────────────────

-- Lectura pública de reseñas activas
CREATE POLICY "resenas_lectura_publica" ON public.resenas
  FOR SELECT USING (activo = TRUE);

-- Solo usuarios autenticados pueden crear reseñas
CREATE POLICY "resenas_insertar_autenticado" ON public.resenas
  FOR INSERT WITH CHECK (
    auth.uid() IS NOT NULL
    AND auth.uid() = autor_id
  );

-- Solo el autor puede editar su reseña
CREATE POLICY "resenas_editar_propia" ON public.resenas
  FOR UPDATE USING (auth.uid() = autor_id);

-- Solo el autor o admin puede borrar
CREATE POLICY "resenas_borrar_propia_o_admin" ON public.resenas
  FOR DELETE USING (
    auth.uid() = autor_id
    OR EXISTS (
      SELECT 1 FROM public.perfiles
      WHERE id = auth.uid() AND rol = 'admin'
    )
  );

-- ──────────────────────────────────────
-- POLÍTICAS: VISITAS
-- ──────────────────────────────────────

-- Solo el propio usuario puede ver SUS visitas
CREATE POLICY "visitas_lectura_propia" ON public.visitas
  FOR SELECT USING (auth.uid() = visitante_id);

-- Admins pueden ver todas las visitas
CREATE POLICY "visitas_lectura_admin" ON public.visitas
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.perfiles
      WHERE id = auth.uid() AND rol = 'admin'
    )
  );

-- Solo el propio usuario puede registrar su visita
CREATE POLICY "visitas_insertar_propio" ON public.visitas
  FOR INSERT WITH CHECK (
    auth.uid() IS NOT NULL
    AND auth.uid() = visitante_id
  );

-- ──────────────────────────────────────
-- POLÍTICAS: VERIFICACIONES
-- ──────────────────────────────────────

-- Cualquiera puede ver qué negocios tienen cuántas verificaciones
CREATE POLICY "verificaciones_lectura_publica" ON public.verificaciones
  FOR SELECT USING (TRUE);

-- Solo usuarios autenticados pueden verificar
CREATE POLICY "verificaciones_insertar_autenticado" ON public.verificaciones
  FOR INSERT WITH CHECK (
    auth.uid() IS NOT NULL
    AND auth.uid() = verificador_id
  );

-- ──────────────────────────────────────
-- POLÍTICAS: CATÁLOGOS (solo lectura pública)
-- ──────────────────────────────────────

CREATE POLICY "categorias_lectura_publica" ON public.categorias
  FOR SELECT USING (activo = TRUE);

CREATE POLICY "badges_lectura_publica" ON public.badges
  FOR SELECT USING (TRUE);

CREATE POLICY "negocio_badges_lectura_publica" ON public.negocio_badges
  FOR SELECT USING (TRUE);


-- ============================================================
-- PASO 16: SEED DATA — Datos iniciales
-- ============================================================

-- Categorías (12 para el MVP)
INSERT INTO public.categorias (nombre, descripcion, icono, color_hex, grupo, orden) VALUES
  -- Grupo: Alimentos
  ('Tortillería',           'Tortillas artesanales y de máquina',          '🌽', '#C0392B', 'alimentos', 1),
  ('Fonda y Antojitos',     'Comida casera, guisos y antojitos mexicanos', '🥗', '#E65100', 'alimentos', 2),
  ('Verdulería',            'Frutas, verduras y legumbres frescas',        '🥦', '#1A7A4A', 'alimentos', 3),
  ('Cremería y Lácteos',    'Quesos, crema, yogurt y lácteos locales',     '🥛', '#1565C0', 'alimentos', 4),
  ('Panadería y Dulcería',  'Pan artesanal, pasteles y dulces típicos',    '🍞', '#F4C430', 'alimentos', 5),
  ('Pollería y Carnicería', 'Pollo, carne y derivados frescos',            '🐔', '#C0392B', 'alimentos', 6),
  ('Tiendas a Granel',      'Arroz, frijol, especias y semillas a granel', '🧺', '#1A7A4A', 'alimentos', 7),
  ('Abarrotes y Tiendita',  'Tienda de conveniencia de barrio',            '🏪', '#E65100', 'alimentos', 8),
  ('Purificadora de Agua',  'Agua purificada y garrafones',                '💧', '#1565C0', 'alimentos', 9),
  -- Grupo: Servicios
  ('Mecánico y Talachero',  'Talleres mecánicos y servicio de llantas',   '🔧', '#E65100', 'servicios', 10),
  ('Ferretería y Herrería', 'Herramientas, materiales y trabajos en metal','⚒️', '#5D4037', 'servicios', 11),
  -- Grupo: Economía Circular
  ('Moda Circular y Bazar', 'Ropa de segunda mano, bazares y trueque',    '👗', '#880E4F', 'circular',  12);

-- Badges catálogo
INSERT INTO public.badges (tipo, nombre, descripcion, icono, color_hex, criterio) VALUES
  ('verificado_comunidad', 'Verificado por vecinos',  'La comunidad confirmó que este negocio existe',     '✓', '#1A7A4A', 'Mínimo 5 vecinos confirmaron su existencia'),
  ('top_rated',            'Top del barrio',          'Calificación de 4.5 o más con mínimo 10 reseñas',  '⭐', '#F4C430', 'Rating >= 4.5 con >= 10 reseñas'),
  ('eco_friendly',         'Eco-friendly',            'El negocio declaró prácticas sustentables',         '🌿', '#1A7A4A', 'El vendedor completó la sección de prácticas eco'),
  ('historia_local',       'Historia local',          'Lleva 15 o más años siendo parte del barrio',       '📜', '#880E4F', 'anios_en_barrio >= 15'),
  ('muy_visitado',         'Muy visitado',            'Está entre los negocios más visitados de su zona',  '🔥', '#E65100', 'Top 10% de visitas en su colonia');


-- ============================================================
-- PASO 17: GRANT DE PERMISOS
-- Supabase necesita que se otorguen permisos explícitos
-- ============================================================

-- anon: usuarios no autenticados (solo lectura pública)
GRANT SELECT ON public.categorias TO anon;
GRANT SELECT ON public.badges TO anon;
GRANT SELECT ON public.negocio_badges TO anon;
GRANT SELECT ON public.v_negocios_directorio TO anon;
GRANT EXECUTE ON FUNCTION public.buscar_negocios_cercanos TO anon;
GRANT EXECUTE ON FUNCTION public.distancia_km TO anon;

-- authenticated: usuarios con sesión activa
GRANT SELECT, INSERT, UPDATE ON public.perfiles TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.negocios TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.resenas TO authenticated;
GRANT SELECT, INSERT ON public.visitas TO authenticated;
GRANT SELECT, INSERT ON public.verificaciones TO authenticated;
GRANT SELECT ON public.categorias TO authenticated;
GRANT SELECT ON public.badges TO authenticated;
GRANT SELECT ON public.negocio_badges TO authenticated;
GRANT SELECT ON public.v_negocios_directorio TO authenticated;
GRANT SELECT ON public.v_impacto_usuario TO authenticated;
GRANT EXECUTE ON FUNCTION public.buscar_negocios_cercanos TO authenticated;
GRANT EXECUTE ON FUNCTION public.calcular_co2 TO authenticated;
GRANT EXECUTE ON FUNCTION public.distancia_km TO authenticated;

-- ============================================================
-- FIN DEL SCRIPT
-- Verificación: ejecuta esto para confirmar que todo se creó:
-- SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';
-- SELECT routine_name FROM information_schema.routines WHERE routine_schema = 'public';
-- ============================================================
