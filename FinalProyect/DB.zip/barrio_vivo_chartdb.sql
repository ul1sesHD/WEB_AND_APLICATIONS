-- ============================================================
-- BARRIO VIVO — Script para ChartDB
-- URL: https://chartdb.io
-- Instrucciones:
--   1. Ve a https://chartdb.io
--   2. Click "New Diagram" → "Import SQL"
--   3. Pega TODO este script y click "Import"
-- ============================================================
-- ChartDB detecta automáticamente las relaciones por FK.
-- Este script es una versión simplificada sin PostGIS ni
-- funciones complejas, para compatibilidad máxima con ChartDB.
-- ============================================================

CREATE TABLE perfiles (
  id              UUID PRIMARY KEY,
  nombre          VARCHAR(100)  NOT NULL,
  telefono        VARCHAR(20),
  rol             VARCHAR(20)   NOT NULL DEFAULT 'usuario',
  colonia         VARCHAR(100),
  ciudad          VARCHAR(100)  DEFAULT 'Ciudad de México',
  lat             DECIMAL(10,7),
  lng             DECIMAL(10,7),
  avatar_url      TEXT,
  activo          BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at      TIMESTAMPTZ
);

CREATE TABLE categorias (
  id              UUID PRIMARY KEY,
  nombre          VARCHAR(100)  NOT NULL UNIQUE,
  descripcion     TEXT,
  icono           VARCHAR(10)   NOT NULL,
  color_hex       VARCHAR(7)    NOT NULL DEFAULT '#C0392B',
  grupo           VARCHAR(50)   NOT NULL,
  orden           SMALLINT      NOT NULL DEFAULT 0,
  activo          BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE TABLE negocios (
  id                    UUID PRIMARY KEY,
  propietario_id        UUID          NOT NULL,
  categoria_id          UUID          NOT NULL,
  nombre                VARCHAR(150)  NOT NULL,
  descripcion           TEXT,
  historia              TEXT,
  cita_vendedor         TEXT,
  nombre_vendedor       VARCHAR(100),
  telefono              VARCHAR(20),
  whatsapp              VARCHAR(20),
  sitio_web             TEXT,
  lat                   DECIMAL(10,7) NOT NULL,
  lng                   DECIMAL(10,7) NOT NULL,
  direccion             TEXT          NOT NULL,
  colonia               VARCHAR(100)  NOT NULL,
  ciudad                VARCHAR(100)  NOT NULL DEFAULT 'Ciudad de México',
  referencia            TEXT,
  horario               TEXT,
  anios_en_barrio       SMALLINT,
  foto_url              TEXT,
  foto_hero_url         TEXT,
  es_eco_friendly       BOOLEAN       NOT NULL DEFAULT FALSE,
  practicas_eco         TEXT,
  estado                VARCHAR(20)   NOT NULL DEFAULT 'pendiente',
  rating_promedio       DECIMAL(3,2)  DEFAULT 0.00,
  total_resenas         INTEGER       NOT NULL DEFAULT 0,
  total_visitas         INTEGER       NOT NULL DEFAULT 0,
  total_verificaciones  INTEGER       NOT NULL DEFAULT 0,
  created_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  deleted_at            TIMESTAMPTZ,
  FOREIGN KEY (propietario_id) REFERENCES perfiles(id),
  FOREIGN KEY (categoria_id)   REFERENCES categorias(id)
);

CREATE TABLE resenas (
  id              UUID PRIMARY KEY,
  negocio_id      UUID          NOT NULL,
  autor_id        UUID          NOT NULL,
  rating          SMALLINT      NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comentario      TEXT,
  activo          BOOLEAN       NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  FOREIGN KEY (negocio_id) REFERENCES negocios(id),
  FOREIGN KEY (autor_id)   REFERENCES perfiles(id),
  UNIQUE (negocio_id, autor_id)
);

CREATE TABLE visitas (
  id                UUID PRIMARY KEY,
  negocio_id        UUID          NOT NULL,
  visitante_id      UUID          NOT NULL,
  km_distancia      DECIMAL(8,3),
  co2_ahorrado_kg   DECIMAL(8,4),
  gasto_reportado   DECIMAL(10,2),
  modo              VARCHAR(20)   NOT NULL DEFAULT 'manual',
  lat_visita        DECIMAL(10,7),
  lng_visita        DECIMAL(10,7),
  created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  FOREIGN KEY (negocio_id)    REFERENCES negocios(id),
  FOREIGN KEY (visitante_id)  REFERENCES perfiles(id)
);

CREATE TABLE verificaciones (
  id              UUID PRIMARY KEY,
  negocio_id      UUID          NOT NULL,
  verificador_id  UUID          NOT NULL,
  confirma        BOOLEAN       NOT NULL DEFAULT TRUE,
  nota            TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  FOREIGN KEY (negocio_id)     REFERENCES negocios(id),
  FOREIGN KEY (verificador_id) REFERENCES perfiles(id),
  UNIQUE (negocio_id, verificador_id)
);

CREATE TABLE badges (
  id              UUID PRIMARY KEY,
  tipo            VARCHAR(50)   NOT NULL UNIQUE,
  nombre          VARCHAR(80)   NOT NULL,
  descripcion     TEXT,
  icono           VARCHAR(10)   NOT NULL,
  color_hex       VARCHAR(7)    NOT NULL DEFAULT '#1A7A4A',
  criterio        TEXT          NOT NULL
);

CREATE TABLE negocio_badges (
  id              UUID PRIMARY KEY,
  negocio_id      UUID          NOT NULL,
  badge_tipo      VARCHAR(50)   NOT NULL,
  otorgado_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  FOREIGN KEY (negocio_id)  REFERENCES negocios(id),
  FOREIGN KEY (badge_tipo)  REFERENCES badges(tipo),
  UNIQUE (negocio_id, badge_tipo)
);

-- ============================================================
-- RELACIONES DETECTADAS POR CHARTDB:
--
-- perfiles        1 ──< negocios       (propietario_id)
-- categorias      1 ──< negocios       (categoria_id)
-- negocios        1 ──< resenas        (negocio_id)
-- perfiles        1 ──< resenas        (autor_id)
-- negocios        1 ──< visitas        (negocio_id)
-- perfiles        1 ──< visitas        (visitante_id)
-- negocios        1 ──< verificaciones (negocio_id)
-- perfiles        1 ──< verificaciones (verificador_id)
-- negocios        1 ──< negocio_badges (negocio_id)
-- badges          1 ──< negocio_badges (badge_tipo)
--
-- 10 entidades   |   10 relaciones   |   ACID compliant
-- ============================================================
