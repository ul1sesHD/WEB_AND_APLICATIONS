-- ============================================================
-- BARRIO VIVO — Seed Data de Ejemplo
-- Ejecutar DESPUÉS de barrio_vivo_supabase.sql
-- Contiene: usuarios demo, negocios reales de CDMX y visitas previas
-- ============================================================
-- IMPORTANTE: En Supabase, los usuarios de auth.users se crean
-- via el Dashboard o la API de Auth, NO con INSERT directo.
-- Este script usa UUIDs fijos para que las FKs funcionen.
-- Pasos:
--   1. Crea los usuarios en Supabase Auth Dashboard primero
--   2. Copia sus UUIDs reales en las variables de abajo
--   3. Ejecuta este script en SQL Editor
-- ============================================================

-- ============================================================
-- SECCIÓN A: PERFILES DE EJEMPLO
-- (Se crean automáticamente vía trigger al registrar en Auth,
--  pero aquí los actualizamos con datos completos para el demo)
-- ============================================================

-- Para el demo usamos UUIDs fijos. En producción vendrán de auth.users.
-- Puedes crear estos usuarios en: Supabase > Auth > Users > Add user

-- Usuario 1: Vendedora — Doña Carmen (tiene tortillería)
INSERT INTO public.perfiles (id, nombre, telefono, rol, colonia, ciudad, lat, lng)
VALUES (
  '11111111-1111-1111-1111-111111111111',
  'Carmen Ramírez Flores',
  '5512345678',
  'vendedor',
  'Del Carmen',
  'Ciudad de México',
  19.3476,
  -99.1620
)
ON CONFLICT (id) DO UPDATE SET
  nombre   = EXCLUDED.nombre,
  telefono = EXCLUDED.telefono,
  rol      = EXCLUDED.rol,
  colonia  = EXCLUDED.colonia,
  lat      = EXCLUDED.lat,
  lng      = EXCLUDED.lng;

-- Usuario 2: Vendedor — Don Jorge (mecánico)
INSERT INTO public.perfiles (id, nombre, telefono, rol, colonia, ciudad, lat, lng)
VALUES (
  '22222222-2222-2222-2222-222222222222',
  'Jorge Mendoza López',
  '5598765432',
  'vendedor',
  'Pedregal de Santo Domingo',
  'Ciudad de México',
  19.3310,
  -99.1580
)
ON CONFLICT (id) DO UPDATE SET
  nombre = EXCLUDED.nombre, rol = EXCLUDED.rol,
  colonia = EXCLUDED.colonia, lat = EXCLUDED.lat, lng = EXCLUDED.lng;

-- Usuario 3: Vendedora — Doña Lupita (fonda)
INSERT INTO public.perfiles (id, nombre, telefono, rol, colonia, ciudad, lat, lng)
VALUES (
  '33333333-3333-3333-3333-333333333333',
  'Guadalupe Torres Vega',
  '5545671234',
  'vendedor',
  'Copilco Universidad',
  'Ciudad de México',
  19.3389,
  -99.1881
)
ON CONFLICT (id) DO UPDATE SET
  nombre = EXCLUDED.nombre, rol = EXCLUDED.rol,
  colonia = EXCLUDED.colonia, lat = EXCLUDED.lat, lng = EXCLUDED.lng;

-- Usuario 4: Consumidor consciente — María González
INSERT INTO public.perfiles (id, nombre, rol, colonia, ciudad, lat, lng)
VALUES (
  '44444444-4444-4444-4444-444444444444',
  'María González Soto',
  'usuario',
  'Coyoacán',
  'Ciudad de México',
  19.3432,
  -99.1619
)
ON CONFLICT (id) DO UPDATE SET
  nombre = EXCLUDED.nombre, colonia = EXCLUDED.colonia;

-- Usuario 5: Consumidor — Alejandro Ruiz
INSERT INTO public.perfiles (id, nombre, rol, colonia, ciudad, lat, lng)
VALUES (
  '55555555-5555-5555-5555-555555555555',
  'Alejandro Ruiz Morales',
  'usuario',
  'Del Carmen',
  'Ciudad de México',
  19.3455,
  -99.1600
)
ON CONFLICT (id) DO UPDATE SET
  nombre = EXCLUDED.nombre, colonia = EXCLUDED.colonia;

-- Usuario 6: Vendedora — Señora Patricia (bazar circular)
INSERT INTO public.perfiles (id, nombre, telefono, rol, colonia, ciudad, lat, lng)
VALUES (
  '66666666-6666-6666-6666-666666666666',
  'Patricia Herrera Ríos',
  '5578904321',
  'vendedor',
  'Coyoacán',
  'Ciudad de México',
  19.3500,
  -99.1650
)
ON CONFLICT (id) DO UPDATE SET
  nombre = EXCLUDED.nombre, rol = EXCLUDED.rol,
  colonia = EXCLUDED.colonia, lat = EXCLUDED.lat, lng = EXCLUDED.lng;

-- Usuario 7: Admin
INSERT INTO public.perfiles (id, nombre, rol, colonia, ciudad)
VALUES (
  '77777777-7777-7777-7777-777777777777',
  'Admin Barrio Vivo',
  'admin',
  'Coyoacán',
  'Ciudad de México'
)
ON CONFLICT (id) DO UPDATE SET rol = 'admin';


-- ============================================================
-- SECCIÓN B: NEGOCIOS DE EJEMPLO
-- Coordenadas reales de la zona Coyoacán / Del Carmen / Copilco
-- ============================================================

-- Necesitamos los IDs de categorías. Los obtenemos por nombre.
DO $$
DECLARE
  cat_tortilleria     UUID;
  cat_fonda           UUID;
  cat_verduleria      UUID;
  cat_cremeria        UUID;
  cat_panaderia       UUID;
  cat_mecanico        UUID;
  cat_abarrotes       UUID;
  cat_purificadora    UUID;
  cat_circular        UUID;
  cat_polleria        UUID;

  neg_tortilleria     UUID := 'aaaa0001-0000-0000-0000-000000000001';
  neg_fonda_lupita    UUID := 'aaaa0002-0000-0000-0000-000000000002';
  neg_verduleria      UUID := 'aaaa0003-0000-0000-0000-000000000003';
  neg_cremeria        UUID := 'aaaa0004-0000-0000-0000-000000000004';
  neg_panaderia       UUID := 'aaaa0005-0000-0000-0000-000000000005';
  neg_mecanico        UUID := 'aaaa0006-0000-0000-0000-000000000006';
  neg_abarrotes       UUID := 'aaaa0007-0000-0000-0000-000000000007';
  neg_purificadora    UUID := 'aaaa0008-0000-0000-0000-000000000008';
  neg_bazar           UUID := 'aaaa0009-0000-0000-0000-000000000009';
  neg_polleria        UUID := 'aaaa0010-0000-0000-0000-000000000010';

BEGIN
  -- Obtener IDs de categorías
  SELECT id INTO cat_tortilleria  FROM public.categorias WHERE nombre = 'Tortillería';
  SELECT id INTO cat_fonda        FROM public.categorias WHERE nombre = 'Fonda y Antojitos';
  SELECT id INTO cat_verduleria   FROM public.categorias WHERE nombre = 'Verdulería';
  SELECT id INTO cat_cremeria     FROM public.categorias WHERE nombre = 'Cremería y Lácteos';
  SELECT id INTO cat_panaderia    FROM public.categorias WHERE nombre = 'Panadería y Dulcería';
  SELECT id INTO cat_mecanico     FROM public.categorias WHERE nombre = 'Mecánico y Talachero';
  SELECT id INTO cat_abarrotes    FROM public.categorias WHERE nombre = 'Abarrotes y Tiendita';
  SELECT id INTO cat_purificadora FROM public.categorias WHERE nombre = 'Purificadora de Agua';
  SELECT id INTO cat_circular     FROM public.categorias WHERE nombre = 'Moda Circular y Bazar';
  SELECT id INTO cat_polleria     FROM public.categorias WHERE nombre = 'Pollería y Carnicería';

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 1: Tortillería Doña Carmen (verificado, top del barrio)
  -- Coyoacán, cerca del mercado
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    telefono, whatsapp,
    ubicacion, direccion, colonia, ciudad, referencia,
    horario, anios_en_barrio,
    foto_url,
    es_eco_friendly, practicas_eco,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_tortilleria,
    '11111111-1111-1111-1111-111111111111',
    cat_tortilleria,
    'Tortillería Doña Carmen',
    'Tortillas artesanales a mano con maíz criollo de Tlaxcala. Nixtamal propio desde 1984.',
    'Mi mamá empezó con este comal cuando yo tenía 8 años. Llegamos al barrio con una olla, un comal y las manos llenas de ganas. Hoy soy yo quien carga el metate, pero el maíz es el mismo: criollo de Tlaxcala, de la misma familia de campesinos con quien mi mamá hizo trato hace 40 años.',
    'Las tortillas se hacen a mano porque con máquina no saben igual. El comal tiene 40 años de vida y así va a seguir.',
    'Carmen Ramírez',
    '5512345678',
    '5512345678',
    ST_SetSRID(ST_MakePoint(-99.1620, 19.3476), 4326)::GEOGRAPHY,
    'Calle Higuera 142, Local 3',
    'Del Carmen',
    'Ciudad de México',
    'A media cuadra de la Farmacia Benavides, junto a la papelería azul',
    '{"lunes":{"abre":"07:00","cierra":"14:00","cerrado":false},"martes":{"abre":"07:00","cierra":"14:00","cerrado":false},"miercoles":{"abre":"07:00","cierra":"14:00","cerrado":false},"jueves":{"abre":"07:00","cierra":"14:00","cerrado":false},"viernes":{"abre":"07:00","cierra":"14:00","cerrado":false},"sabado":{"abre":"07:00","cierra":"13:00","cerrado":false},"domingo":{"abre":"00:00","cierra":"00:00","cerrado":true}}',
    41,
    'https://images.unsplash.com/photo-1615361200141-f45040f367be?w=400',
    TRUE,
    'Usamos maíz criollo local. Sin conservadores. El nixtamal lo hacemos nosotros con cal de origen mineral.',
    'activo',
    4.90, 47, 128, 12
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 2: Fonda Doña Lupita (activo, verificado)
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    telefono, whatsapp,
    ubicacion, direccion, colonia, ciudad, referencia,
    horario, anios_en_barrio, foto_url,
    es_eco_friendly, estado,
    rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_fonda_lupita,
    '33333333-3333-3333-3333-333333333333',
    cat_fonda,
    'Fonda el Buen Sazón de Lupita',
    'Comida casera de lunes a sábado. Menú del día con sopa, guiso, agua y postre. Todo hecho en casa.',
    'Empecé vendiendo tortas en la puerta de mi casa cuando quedé viuda. Un vecino me dijo: Lupita, guísas tan rico que deberías poner fonda. Y aquí estamos, 22 años después. Los estudiantes de la UNAM son mi familia.',
    'Aquí no se come comida de fábrica. Todo lo hice yo esta mañana.',
    'Guadalupe Torres',
    '5545671234',
    '5545671234',
    ST_SetSRID(ST_MakePoint(-99.1881, 19.3389), 4326)::GEOGRAPHY,
    'Av. Copilco 318, planta baja',
    'Copilco Universidad',
    'Ciudad de México',
    'Enfrente de la entrada 3 de CU, junto al Oxxo',
    '{"lunes":{"abre":"08:00","cierra":"17:00","cerrado":false},"martes":{"abre":"08:00","cierra":"17:00","cerrado":false},"miercoles":{"abre":"08:00","cierra":"17:00","cerrado":false},"jueves":{"abre":"08:00","cierra":"17:00","cerrado":false},"viernes":{"abre":"08:00","cierra":"17:00","cerrado":false},"sabado":{"abre":"09:00","cierra":"15:00","cerrado":false},"domingo":{"abre":"00:00","cierra":"00:00","cerrado":true}}',
    22,
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400',
    FALSE,
    'activo',
    4.70, 31, 96, 8
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 3: Verdulería El Fresquito
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, cita_vendedor, nombre_vendedor,
    telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    es_eco_friendly, practicas_eco,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_verduleria,
    '11111111-1111-1111-1111-111111111111',
    cat_verduleria,
    'Verdulería El Fresquito',
    'Frutas y verduras directas de la Central de Abastos. Llegamos todos los días a las 5am para traerte lo más fresco.',
    'Llegamos a la Central antes de que salga el sol para que tú tengas lo mejor.',
    'Roberto Sánchez',
    '5523456789',
    ST_SetSRID(ST_MakePoint(-99.1605, 19.3491), 4326)::GEOGRAPHY,
    'Calle Francisco Sosa 234',
    'Del Carmen',
    'Ciudad de México',
    '{"lunes":{"abre":"07:00","cierra":"20:00","cerrado":false},"martes":{"abre":"07:00","cierra":"20:00","cerrado":false},"miercoles":{"abre":"07:00","cierra":"20:00","cerrado":false},"jueves":{"abre":"07:00","cierra":"20:00","cerrado":false},"viernes":{"abre":"07:00","cierra":"20:00","cerrado":false},"sabado":{"abre":"07:00","cierra":"18:00","cerrado":false},"domingo":{"abre":"08:00","cierra":"14:00","cerrado":false}}',
    9,
    'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400',
    TRUE,
    'Compramos directo al productor en temporada. Sin intermediarios. Los sobrantes van a vecinos o compostamos.',
    'activo',
    4.50, 18, 74, 6
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 4: Cremería La Norteña
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_cremeria,
    '33333333-3333-3333-3333-333333333333',
    cat_cremeria,
    'Cremería La Norteña',
    'Quesos de rancho, crema espesa, requesón y mantequilla. Traídos desde Querétaro cada semana.',
    'Mi familia tiene una pequeña quesería en el rancho desde hace tres generaciones. Yo vine a la ciudad a estudiar y me traje el queso. Ahora vendo a varios vecinos y restaurantes del barrio.',
    'El queso de rancho no tiene comparación con el de caja. Una vez que lo pruebas, no hay vuelta atrás.',
    'Ana María Ortega',
    '5534567890',
    ST_SetSRID(ST_MakePoint(-99.1635, 19.3460), 4326)::GEOGRAPHY,
    'Calle Tres Cruces 89',
    'Del Carmen',
    'Ciudad de México',
    '{"lunes":{"abre":"09:00","cierra":"19:00","cerrado":false},"martes":{"abre":"09:00","cierra":"19:00","cerrado":false},"miercoles":{"abre":"09:00","cierra":"19:00","cerrado":false},"jueves":{"abre":"09:00","cierra":"19:00","cerrado":false},"viernes":{"abre":"09:00","cierra":"19:00","cerrado":false},"sabado":{"abre":"09:00","cierra":"17:00","cerrado":false},"domingo":{"abre":"00:00","cierra":"00:00","cerrado":true}}',
    7,
    'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400',
    'activo',
    4.80, 24, 58, 7
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 5: Panadería La Esperanza (historia local: 38 años)
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    es_eco_friendly,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_panaderia,
    '22222222-2222-2222-2222-222222222222',
    cat_panaderia,
    'Panadería La Esperanza',
    'Pan artesanal hecho con fermentación natural. Conchas, bolillos, cuernos y pan de temporada.',
    'Mi abuelo fundó esta panadería en 1987 en esta misma esquina. Cuando él faltó, mi papá siguió. Ahora soy yo quien madruga. El horno nunca se ha apagado en 38 años.',
    'El olor del pan recién horneado es la mejor alarma del barrio. Nosotros despertamos al vecindario.',
    'Ernesto Gutiérrez',
    '5556789012',
    ST_SetSRID(ST_MakePoint(-99.1658, 19.3510), 4326)::GEOGRAPHY,
    'Esquina Aguayo y Higuera s/n',
    'Del Carmen',
    'Ciudad de México',
    '{"lunes":{"abre":"06:00","cierra":"21:00","cerrado":false},"martes":{"abre":"06:00","cierra":"21:00","cerrado":false},"miercoles":{"abre":"06:00","cierra":"21:00","cerrado":false},"jueves":{"abre":"06:00","cierra":"21:00","cerrado":false},"viernes":{"abre":"06:00","cierra":"21:00","cerrado":false},"sabado":{"abre":"06:00","cierra":"21:00","cerrado":false},"domingo":{"abre":"07:00","cierra":"18:00","cerrado":false}}',
    38,
    'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
    FALSE,
    'activo',
    5.00, 52, 143, 14
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 6: Taller Mecánico Don Jorge
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    telefono, whatsapp,
    ubicacion, direccion, colonia, ciudad, referencia,
    horario, anios_en_barrio, foto_url,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_mecanico,
    '22222222-2222-2222-2222-222222222222',
    cat_mecanico,
    'Taller Mecánico Don Jorge',
    'Servicio mecánico general, frenos, suspensión, hojalatería y pintura. Diagnóstico gratuito para vecinos del barrio.',
    'Empecé como aprendiz en Iztapalapa con 15 años. Me vine a Coyoacán con mis herramientas y una deuda. Ya pagué la deuda, ya son 18 años. El barrio me dio de comer y yo le doy el mejor servicio.',
    'Con el vecino no hay letra chica. Te digo el precio antes de tocar el coche y así queda.',
    'Jorge Mendoza',
    '5598765432',
    '5598765432',
    ST_SetSRID(ST_MakePoint(-99.1580, 19.3310), 4326)::GEOGRAPHY,
    'Calle Malintzin 445',
    'Pedregal de Santo Domingo',
    'Ciudad de México',
    'Local con puerta de herrería verde, frente al parque',
    '{"lunes":{"abre":"08:00","cierra":"19:00","cerrado":false},"martes":{"abre":"08:00","cierra":"19:00","cerrado":false},"miercoles":{"abre":"08:00","cierra":"19:00","cerrado":false},"jueves":{"abre":"08:00","cierra":"19:00","cerrado":false},"viernes":{"abre":"08:00","cierra":"19:00","cerrado":false},"sabado":{"abre":"09:00","cierra":"15:00","cerrado":false},"domingo":{"abre":"00:00","cierra":"00:00","cerrado":true}}',
    18,
    'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400',
    'activo',
    4.50, 22, 41, 5
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 7: Abarrotes y Miscelánea El Barrio
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, cita_vendedor, nombre_vendedor,
    telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_abarrotes,
    '66666666-6666-6666-6666-666666666666',
    cat_abarrotes,
    'Miscelánea El Barrio',
    'Abarrotes, botanas, refrescos, artículos de limpieza y lo que necesitas. Abierto casi todo el día.',
    'Aquí encuentras lo que no encuentras en el Oxxo y a mejor precio.',
    'Señora Conchita',
    '5567890123',
    ST_SetSRID(ST_MakePoint(-99.1640, 19.3480), 4326)::GEOGRAPHY,
    'Calle Aguayo 78 esquina Tres Cruces',
    'Del Carmen',
    'Ciudad de México',
    '{"lunes":{"abre":"07:00","cierra":"22:00","cerrado":false},"martes":{"abre":"07:00","cierra":"22:00","cerrado":false},"miercoles":{"abre":"07:00","cierra":"22:00","cerrado":false},"jueves":{"abre":"07:00","cierra":"22:00","cerrado":false},"viernes":{"abre":"07:00","cierra":"22:00","cerrado":false},"sabado":{"abre":"07:00","cierra":"22:00","cerrado":false},"domingo":{"abre":"08:00","cierra":"20:00","cerrado":false}}',
    12,
    'https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=400',
    'activo',
    4.20, 14, 89, 9
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 8: Purificadora El Manantial
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, nombre_vendedor,
    telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    es_eco_friendly, practicas_eco,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_purificadora,
    '33333333-3333-3333-3333-333333333333',
    cat_purificadora,
    'Purificadora El Manantial',
    'Agua purificada por ósmosis inversa y ultravioleta. Garrafones, botellas y servicio a domicilio en el barrio.',
    'Don Aurelio',
    '5578901234',
    ST_SetSRID(ST_MakePoint(-99.1625, 19.3498), 4326)::GEOGRAPHY,
    'Calle Vallarta 12',
    'Del Carmen',
    'Ciudad de México',
    '{"lunes":{"abre":"08:00","cierra":"19:00","cerrado":false},"martes":{"abre":"08:00","cierra":"19:00","cerrado":false},"miercoles":{"abre":"08:00","cierra":"19:00","cerrado":false},"jueves":{"abre":"08:00","cierra":"19:00","cerrado":false},"viernes":{"abre":"08:00","cierra":"19:00","cerrado":false},"sabado":{"abre":"08:00","cierra":"17:00","cerrado":false},"domingo":{"abre":"09:00","cierra":"14:00","cerrado":false}}',
    6,
    'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400',
    TRUE,
    'Reutilizamos garrafones. Menos plástico, menos basura. El 90% de nuestros clientes usan el mismo garrafón por años.',
    'activo',
    4.30, 11, 52, 5
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 9: Bazar Segunda Vida (economía circular)
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, historia, cita_vendedor, nombre_vendedor,
    whatsapp,
    ubicacion, direccion, colonia, ciudad, referencia,
    horario, anios_en_barrio, foto_url,
    es_eco_friendly, practicas_eco,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_bazar,
    '66666666-6666-6666-6666-666666666666',
    cat_circular,
    'Bazar Segunda Vida',
    'Ropa, libros, discos, muebles y objetos de segunda mano. Todo revisado y con precio justo. Sábados y domingos en el parque.',
    'Empecé el bazar porque odiaba ver cómo la gente tiraba cosas perfectamente útiles. Primero lo hacía con mis vecinas en el patio. Ahora somos 15 familias que rotamos en el parque cada semana.',
    'Una prenda que tú no usas puede ser la favorita de alguien más. Dale una segunda oportunidad.',
    'Patricia Herrera',
    '5578904321',
    ST_SetSRID(ST_MakePoint(-99.1650, 19.3500), 4326)::GEOGRAPHY,
    'Parque de El Ahuehuete, puesto norte',
    'Coyoacán',
    'Ciudad de México',
    'En el parque grande, junto a la fuente. Busca los toldos rosas.',
    '{"lunes":{"abre":"00:00","cierra":"00:00","cerrado":true},"martes":{"abre":"00:00","cierra":"00:00","cerrado":true},"miercoles":{"abre":"00:00","cierra":"00:00","cerrado":true},"jueves":{"abre":"00:00","cierra":"00:00","cerrado":true},"viernes":{"abre":"00:00","cierra":"00:00","cerrado":true},"sabado":{"abre":"09:00","cierra":"18:00","cerrado":false},"domingo":{"abre":"09:00","cierra":"17:00","cerrado":false}}',
    5,
    'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?w=400',
    TRUE,
    'Cero empaques plásticos. Bolsas de tela. Canjeamos objetos además de vender. Lo que no vendemos lo donamos.',
    'activo',
    4.60, 19, 43, 6
  )
  ON CONFLICT (id) DO NOTHING;

  -- ─────────────────────────────────────────────────
  -- NEGOCIO 10: Pollería Don Cuco (pendiente de verificación)
  -- ─────────────────────────────────────────────────
  INSERT INTO public.negocios (
    id, propietario_id, categoria_id,
    nombre, descripcion, nombre_vendedor, telefono,
    ubicacion, direccion, colonia, ciudad,
    horario, anios_en_barrio, foto_url,
    estado, rating_promedio, total_resenas, total_visitas, total_verificaciones
  ) VALUES (
    neg_polleria,
    '22222222-2222-2222-2222-222222222222',
    cat_polleria,
    'Pollería Don Cuco',
    'Pollo fresco, menudencias y carnes. Pollos criados en el Estado de México. Llega martes, jueves y sábado.',
    'Don Cuco',
    '5589012345',
    ST_SetSRID(ST_MakePoint(-99.1598, 19.3472), 4326)::GEOGRAPHY,
    'Mercado Artesanal de Coyoacán, puesto 14',
    'Coyoacán',
    'Ciudad de México',
    '{"martes":{"abre":"07:00","cierra":"15:00","cerrado":false},"jueves":{"abre":"07:00","cierra":"15:00","cerrado":false},"sabado":{"abre":"06:00","cierra":"14:00","cerrado":false}}',
    3,
    'https://images.unsplash.com/photo-1518492104633-130d0cc84637?w=400',
    'pendiente',
    0.00, 0, 2, 1
  )
  ON CONFLICT (id) DO NOTHING;

END $$;


-- ============================================================
-- SECCIÓN C: RESEÑAS DE EJEMPLO
-- ============================================================

-- Reseñas de la tortillería
INSERT INTO public.resenas (negocio_id, autor_id, rating, comentario, created_at)
VALUES
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444', 5,
   'Las mejores tortillas del barrio sin discusión. Se nota que es maíz de verdad.', NOW() - INTERVAL '3 days'),
  ('aaaa0001-0000-0000-0000-000000000001', '55555555-5555-5555-5555-555555555555', 5,
   'Llevo 5 años comprando aquí. Doña Carmen es una institución del barrio.', NOW() - INTERVAL '1 week')
ON CONFLICT (negocio_id, autor_id) DO NOTHING;

-- Reseñas de la fonda
INSERT INTO public.resenas (negocio_id, autor_id, rating, comentario, created_at)
VALUES
  ('aaaa0002-0000-0000-0000-000000000002', '44444444-4444-4444-4444-444444444444', 5,
   'El menú del día está increíble. La sopa de fideos y los chiles rellenos, perfectos.', NOW() - INTERVAL '5 days'),
  ('aaaa0002-0000-0000-0000-000000000002', '55555555-5555-5555-5555-555555555555', 4,
   'Muy rica la comida. A veces hay que esperar pero vale la pena.', NOW() - INTERVAL '2 weeks')
ON CONFLICT (negocio_id, autor_id) DO NOTHING;

-- Reseñas panadería
INSERT INTO public.resenas (negocio_id, autor_id, rating, comentario, created_at)
VALUES
  ('aaaa0005-0000-0000-0000-000000000005', '44444444-4444-4444-4444-444444444444', 5,
   'Las conchas son esponjosas y el bolillo cruje perfecto. Llevo años aquí.', NOW() - INTERVAL '2 days'),
  ('aaaa0005-0000-0000-0000-000000000005', '55555555-5555-5555-5555-555555555555', 5,
   'El pan de muerto en temporada es de otro nivel. No me lo pierdo nunca.', NOW() - INTERVAL '10 days')
ON CONFLICT (negocio_id, autor_id) DO NOTHING;


-- ============================================================
-- SECCIÓN D: VERIFICACIONES DE EJEMPLO
-- ============================================================

INSERT INTO public.verificaciones (negocio_id, verificador_id, confirma, created_at)
VALUES
  -- Tortillería verificada por múltiples vecinos
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444', TRUE, NOW() - INTERVAL '2 months'),
  ('aaaa0001-0000-0000-0000-000000000001', '55555555-5555-5555-5555-555555555555', TRUE, NOW() - INTERVAL '6 weeks'),
  ('aaaa0001-0000-0000-0000-000000000001', '66666666-6666-6666-6666-666666666666', TRUE, NOW() - INTERVAL '1 month'),
  -- Fonda verificada
  ('aaaa0002-0000-0000-0000-000000000002', '44444444-4444-4444-4444-444444444444', TRUE, NOW() - INTERVAL '3 weeks'),
  ('aaaa0002-0000-0000-0000-000000000002', '55555555-5555-5555-5555-555555555555', TRUE, NOW() - INTERVAL '2 weeks'),
  -- Panadería verificada
  ('aaaa0005-0000-0000-0000-000000000005', '44444444-4444-4444-4444-444444444444', TRUE, NOW() - INTERVAL '5 weeks'),
  ('aaaa0005-0000-0000-0000-000000000005', '55555555-5555-5555-5555-555555555555', TRUE, NOW() - INTERVAL '4 weeks'),
  -- Pollería: solo 1 verificación (pendiente)
  ('aaaa0010-0000-0000-0000-000000000010', '44444444-4444-4444-4444-444444444444', TRUE, NOW() - INTERVAL '1 day')
ON CONFLICT (negocio_id, verificador_id) DO NOTHING;


-- ============================================================
-- SECCIÓN E: VISITAS HISTÓRICAS DE EJEMPLO
-- Estas son las visitas "ya registradas" que pediste
-- Muestran el historial de impacto ambiental del barrio
-- ============================================================

INSERT INTO public.visitas (
  negocio_id, visitante_id,
  km_distancia, co2_ahorrado_kg, gasto_reportado,
  modo, created_at
)
VALUES
  -- María González (usuario 4) — visitó tortillería varias veces
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444',
   0.350, public.calcular_co2(0.350), 45.00, 'manual', NOW() - INTERVAL '1 day'),
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444',
   0.350, public.calcular_co2(0.350), 40.00, 'manual', NOW() - INTERVAL '4 days'),
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444',
   0.350, public.calcular_co2(0.350), 42.00, 'manual', NOW() - INTERVAL '8 days'),

  -- María — visitó la fonda
  ('aaaa0002-0000-0000-0000-000000000002', '44444444-4444-4444-4444-444444444444',
   0.620, public.calcular_co2(0.620), 90.00, 'manual', NOW() - INTERVAL '2 days'),
  ('aaaa0002-0000-0000-0000-000000000002', '44444444-4444-4444-4444-444444444444',
   0.620, public.calcular_co2(0.620), 85.00, 'manual', NOW() - INTERVAL '9 days'),

  -- María — visitó panadería
  ('aaaa0005-0000-0000-0000-000000000005', '44444444-4444-4444-4444-444444444444',
   0.450, public.calcular_co2(0.450), 60.00, 'manual', NOW() - INTERVAL '3 days'),
  ('aaaa0005-0000-0000-0000-000000000005', '44444444-4444-4444-4444-444444444444',
   0.450, public.calcular_co2(0.450), 55.00, 'manual', NOW() - INTERVAL '10 days'),

  -- María — visitó purificadora
  ('aaaa0008-0000-0000-0000-000000000008', '44444444-4444-4444-4444-444444444444',
   0.430, public.calcular_co2(0.430), 35.00, 'manual', NOW() - INTERVAL '5 days'),

  -- María — visitó bazar
  ('aaaa0009-0000-0000-0000-000000000009', '44444444-4444-4444-4444-444444444444',
   0.890, public.calcular_co2(0.890), 120.00, 'manual', NOW() - INTERVAL '6 days'),

  -- Alejandro (usuario 5) — tortillería y mecánico
  ('aaaa0001-0000-0000-0000-000000000001', '55555555-5555-5555-5555-555555555555',
   0.380, public.calcular_co2(0.380), 38.00, 'manual', NOW() - INTERVAL '2 days'),
  ('aaaa0006-0000-0000-0000-000000000006', '55555555-5555-5555-5555-555555555555',
   1.100, public.calcular_co2(1.100), 350.00, 'manual', NOW() - INTERVAL '7 days'),
  ('aaaa0007-0000-0000-0000-000000000007', '55555555-5555-5555-5555-555555555555',
   0.210, public.calcular_co2(0.210), 28.00, 'manual', NOW() - INTERVAL '1 day'),
  ('aaaa0003-0000-0000-0000-000000000003', '55555555-5555-5555-5555-555555555555',
   0.520, public.calcular_co2(0.520), 75.00, 'manual', NOW() - INTERVAL '3 days'),

  -- Visitas históricas adicionales (mes pasado) para que los contadores sean realistas
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444',
   0.350, public.calcular_co2(0.350), 40.00, 'manual', NOW() - INTERVAL '15 days'),
  ('aaaa0001-0000-0000-0000-000000000001', '44444444-4444-4444-4444-444444444444',
   0.350, public.calcular_co2(0.350), 43.00, 'manual', NOW() - INTERVAL '22 days'),
  ('aaaa0005-0000-0000-0000-000000000005', '55555555-5555-5555-5555-555555555555',
   0.450, public.calcular_co2(0.450), 65.00, 'manual', NOW() - INTERVAL '14 days'),
  ('aaaa0002-0000-0000-0000-000000000002', '55555555-5555-5555-5555-555555555555',
   0.620, public.calcular_co2(0.620), 88.00, 'manual', NOW() - INTERVAL '18 days');


-- ============================================================
-- SECCIÓN F: ASIGNAR BADGES A NEGOCIOS (basado en datos de ejemplo)
-- ============================================================

-- Badges manuales para el seed data
-- (Normalmente los asignan los triggers automáticamente)
INSERT INTO public.negocio_badges (negocio_id, badge_tipo)
VALUES
  -- Tortillería: verificado, top_rated, eco_friendly, historia_local
  ('aaaa0001-0000-0000-0000-000000000001', 'verificado_comunidad'),
  ('aaaa0001-0000-0000-0000-000000000001', 'top_rated'),
  ('aaaa0001-0000-0000-0000-000000000001', 'eco_friendly'),
  ('aaaa0001-0000-0000-0000-000000000001', 'historia_local'),
  -- Panadería: historia_local (38 años), top_rated, muy_visitado
  ('aaaa0005-0000-0000-0000-000000000005', 'historia_local'),
  ('aaaa0005-0000-0000-0000-000000000005', 'top_rated'),
  ('aaaa0005-0000-0000-0000-000000000005', 'muy_visitado'),
  -- Fonda: verificado, top_rated
  ('aaaa0002-0000-0000-0000-000000000002', 'verificado_comunidad'),
  ('aaaa0002-0000-0000-0000-000000000002', 'top_rated'),
  -- Cremería: top_rated
  ('aaaa0004-0000-0000-0000-000000000004', 'top_rated'),
  -- Purificadora: eco_friendly
  ('aaaa0008-0000-0000-0000-000000000008', 'eco_friendly'),
  -- Bazar: eco_friendly, verificado
  ('aaaa0009-0000-0000-0000-000000000009', 'eco_friendly'),
  ('aaaa0009-0000-0000-0000-000000000009', 'verificado_comunidad'),
  -- Verdulería: eco_friendly
  ('aaaa0003-0000-0000-0000-000000000003', 'eco_friendly')
ON CONFLICT (negocio_id, badge_tipo) DO NOTHING;


-- ============================================================
-- VERIFICACIÓN FINAL
-- Ejecuta estas queries para confirmar que todo está bien:
-- ============================================================

-- Ver resumen de lo que se creó:
-- SELECT 'perfiles' AS tabla, COUNT(*) FROM public.perfiles
-- UNION ALL
-- SELECT 'negocios', COUNT(*) FROM public.negocios
-- UNION ALL
-- SELECT 'resenas', COUNT(*) FROM public.resenas
-- UNION ALL
-- SELECT 'visitas', COUNT(*) FROM public.visitas
-- UNION ALL
-- SELECT 'verificaciones', COUNT(*) FROM public.verificaciones
-- UNION ALL
-- SELECT 'negocio_badges', COUNT(*) FROM public.negocio_badges;

-- Probar la función de búsqueda geográfica (desde Coyoacán, 5km):
-- SELECT nombre, colonia, distancia_km, rating_promedio, badges
-- FROM buscar_negocios_cercanos(19.3432, -99.1619, 5.0)
-- ORDER BY distancia_km;

-- Ver impacto de usuarios:
-- SELECT nombre_usuario, km_totales, co2_total_kg, dinero_local_total, total_visitas
-- FROM public.v_impacto_usuario
-- ORDER BY km_totales DESC;
